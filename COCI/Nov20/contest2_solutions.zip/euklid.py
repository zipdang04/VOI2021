#!/usr/bin/python3
import math

T = int(input())
for _ in range(T):
    g, h = list(map(int, input().split()))

    h_pow = h
    while h_pow <= g:
        h_pow *= h

    b = g * math.ceil(h_pow / g) 
    a = h * b + g

    print(a, b)
