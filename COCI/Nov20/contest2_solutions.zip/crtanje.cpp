#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef double lf;
typedef long double Lf;
typedef pair <int,int> pii;
typedef pair <ll, ll> pll;

#define TRACE(x) cerr << #x << "  " << x << endl
#define FOR(i, a, b) for (int i = (a); i < int(b); i++)
#define REP(i, n) FOR(i, 0, n)
#define all(x) (x).begin(), (x).end()
#define _ << " " <<

#define fi first
#define sec second
#define mp make_pair
#define pb push_back

const int MAXN = 205;

char ans[MAXN][MAXN];

int main() {
  int n;
  cin >> n;
  string s;
  cin >> s;

  memset(ans, '.', sizeof ans);

  int visina = 100;

  int mini = 1320000, maks = -123100;

  REP(i, n) {
    if (s[i] == '+') {
      mini = min(mini, visina);
      maks = max(maks, visina);
      ans[visina][i] = '/';
      visina--;
    }
    if (s[i] == '-') {
      visina++;
      ans[visina][i] = '\\';
      mini = min(mini, visina);
      maks = max(maks, visina);
    }
    if (s[i] == '=') {
      mini = min(mini, visina);
      maks = max(maks, visina);
      ans[visina][i] = '_';
    }
  }

  FOR(i, mini, maks + 1) {
    REP(j, n) printf("%c",ans[i][j]);
    puts("");
  }

  
  return 0;
}

