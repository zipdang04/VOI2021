#include <bits/stdc++.h>

using namespace std;

const int MAXN = 30010;
const int N_CHAR = 26;

int n;
string s[MAXN];
int t[300010][N_CHAR];
bool isLeaf[300010];
int nodeCount = 0;

class Graph {
  vector<int> color;
  vector<int> edge[N_CHAR];
  bool hasCycle;
 public:
  Graph() {
    color.resize(N_CHAR);
    hasCycle = false;
  };

  void dfs(int u) {
    if (hasCycle) return;
    color[u] = 1; // start visit u
    for (int v : edge[u]) {
      if (color[v] == 1) {
        // you found a cycle
        hasCycle = true;
        return;
      }
      if (color[v] == 0) dfs(v);
    }
    color[u] = 2; // finished visiting u
  }

  void AddEdge(int u, int v) {
    edge[u].push_back(v);
  }

  bool HasCycle() {
    for (int i = 0; i < N_CHAR; i++) {
      if (color[i] == 0) {
        dfs(i);
      }
    }
    return hasCycle;
  }
};

void add(const string &s) {
  int curNode = 0;
  for (char c : s) {
    int charId = c - 'a';
    if (t[curNode][charId] == 0) {
      t[curNode][charId] = ++nodeCount;
    }
    curNode = t[curNode][charId];
  }
  isLeaf[curNode] = true;
}

bool canComeFirst(const string &s) {
  int curNode = 0;
  Graph graph = Graph();
  int curStringId = 0;
  for (char c : s) {
    ++curStringId;
    int charId = c - 'a';
    assert(t[curNode][charId] > 0); // check that this node exists.
    // For all nodes that come from the curNode node, the letter of the string s must have the smallest lexicographical order.
    if (isLeaf[t[curNode][charId]] && curStringId < s.size()) {
      // If there is a string prefixed by this string, it certainly cannot be the string with the smallest lexicographical order.
      return false;
    }
    for (int i = 0; i < N_CHAR; i++) {
      if (i == charId || t[curNode][i] == 0) continue;
      graph.AddEdge(charId, i);
    }
    curNode = t[curNode][charId];
  }

  return (!graph.HasCycle());
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
//  if (fopen("a.txt", "r")) {
//    freopen("a.txt", "r", stdin);
//  }
  cin >> n;
  for (int i = 1; i <= n; i++) {
    cin >> s[i];
    add(s[i]);
  }

  vector<int> result;
  for (int i = 1; i <= n; i++) {
    if (canComeFirst(s[i])) {
      result.push_back(i);
    }
  }
  cout << result.size() << endl;
  for (auto id : result) {
    cout << s[id] << endl;
  }
}