
#include <bits/stdc++.h>

using namespace std;

#define Matrix vector<vector<long long>>

long long n, mod;

Matrix operator*(const Matrix &matrixA, const Matrix &matrixB) {
  Matrix matrixC = {{0, 0}, {0, 0}};
  for (int i = 0; i < 2; i++) {
    for (int j = 0; j < 2; j++) {
      for (int k = 0; k < 2; k++) {
        matrixC[i][j] = (matrixC[i][j] + (matrixA[i][k] * matrixB[k][j]) % mod) % mod;
      }
    }
  }
  return matrixC;
}

Matrix power(const Matrix &matrixA, long long k) {
  if (k == 1) return matrixA;
  Matrix ans = power(matrixA, k / 2);
  ans = ans * ans;
  if (k % 2 == 1) ans = ans * matrixA;
  return ans;
}

// f[i] = 8 * f[i-1] - 5 * f[i-2].
// [f[i-2],f[i-1]] * [[0,-5],[1,8]] = [f[i-1],f[i]]

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
//  if (fopen("a.txt", "r")) {
//    freopen("a.txt", "r", stdin);
//  }
  cin >> n >> mod;
  Matrix baseMatrix = {{0, -5}, {1, 8}};
  long long res;
  if (n == 1) {
    res = 8;
  } else {
    Matrix r = power(baseMatrix, n - 1);
    res = (1LL * 8 * r[0][0] + 1LL * 54 * r[1][0]) % mod;
  }
  res = (res - 1 + mod) % mod;
  cout << res;
}
