#include <bits/stdc++.h>

using namespace std;

const int maxn = 300010;
const long long inf = -1e18;

typedef vector<long long> List;

long long biggestSum(const List &f) {
  long long res = inf;
  if (f.size() == 0) return inf;
  long long curMin = f[0];
  for (int i = 1; i < f.size(); i++) {
    res = max(res, f[i] - curMin);
    curMin = min(curMin, f[i]);
  }
  return res;
}

int n;
long long a[maxn], s[maxn];

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
//  if (fopen("a.txt", "r")) {
//    freopen("a.txt", "r", stdin);
//  }
  cin >> n;
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
    s[i] = s[i - 1] + a[i];
  }
  long long res = inf;
  List f;
  for (int start = 0; start <= 2; start++) {
    f.clear();
    for (int i = start; i <= n; i += 3) {
      f.push_back(s[i]);
    }
    res = max(res, biggestSum(f));
  }
  cout << res;
}